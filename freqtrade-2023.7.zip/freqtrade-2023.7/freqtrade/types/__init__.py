from freqtrade.types.valid_exchanges_type import ValidExchangesType  # noqa: F401
